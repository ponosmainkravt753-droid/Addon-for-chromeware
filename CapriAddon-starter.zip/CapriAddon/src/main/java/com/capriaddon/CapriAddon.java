package com.capriaddon;

import net.neoforged.fml.common.Mod;

@Mod(CapriAddon.MOD_ID)
public class CapriAddon {
    public static final String MOD_ID = "capriaddon";

    public CapriAddon() {
        System.out.println("[CapriAddon] Initialized!");
    }
}
